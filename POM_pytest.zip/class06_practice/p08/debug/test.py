# @Author   :muzhe
# @Time     :2022/6/3 7:54
# @File     :test.py
# @Software :PyCharm
from time import sleep
from PYTEST.class06_practice.p08.key_word.keyword import WebKeys
from selenium import webdriver
from PYTEST.class06_practice.p08.locate import allPages

# 淘宝登录验证码解决方案

"""
    使用编写的脚本以debug模式启动谷歌浏览器，会自动加载缓存数据，脚本内容：
    chrome.exe --remote-debugging-port=9222
    必须通过os.popen执行，通过os.system执行命令无效
"""
# os.popen("e:/chrome.bat")
# sleep(5)


# 加载浏览器驱动
options = webdriver.ChromeOptions()
options.debugger_address = '127.0.0.1:9222'
driver = webdriver.Chrome(options=options)
sleep(3)

# 加载浏览器驱动
wk = WebKeys(driver)

# 点击加入购物车
wk.locator(*allPages.page_goodsDetail_cartBtn).click()
sleep(2)

# 切换frame
el = wk.locator(*allPages.page_goodsDetail_loginFrame)
wk.change_frame(el)

# 填写账户密码,去掉了等待时间触发滚动条解锁
wk.locator(*allPages.page_indexLogin_user).send_keys('kankankeji')
# sleep(2)
wk.locator(*allPages.page_indexLogin_pwd).send_keys('9957and77@')
# sleep(2)
wk.locator(*allPages.page_indexLogin_loginBtn).click()
sleep(2)

# 切换到滑块的iframe
el = wk.locator('xpath', "//div[@id='login']//iframe")
wk.change_frame(el)
wk.slider_by_step("//center//span[@id='nc_1_n1z']")
