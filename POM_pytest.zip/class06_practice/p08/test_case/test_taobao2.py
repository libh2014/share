# @Author   :muzhe
# @Time     :2022/6/3 8:30
# @File     :test_taobao2.py
# @Software :PyCharm
from time import sleep

import allure

from PYTEST.class06_practice.p08.VAR.TAOBAO_VAR import *
from PYTEST.class06_practice.p08.locate import allPages
from PYTEST.class06_practice.p08.logic.shopping_page import GoodsSale


@allure.title("淘宝购物")
def test_googsSale(browser):
    # 初始化业务流程
    goodssale = GoodsSale(browser)
    with allure.step("打开浏览器："+TAOBAO_URL):
        goodssale.open(TAOBAO_URL)

    # 搜索商品
    goodssale.goodsSearch("膳魔师")

    # 进行购物
    goodssale.shopping()


def test_del_goods(browser):
    # 服用商品购物流程
    goodssale = GoodsSale(browser)
    goodssale.open(TAOBAO_URL)
    # 搜索商品
    goodssale.goodsSearch("膳魔师")
    # 进行购物
    goodssale.shopping()

    with allure.step("打开购物车"):
        goodssale.open(CART_LOGIN_URL)

    with allure.step("全选商品"):
        goodssale.locator(*allPages.page_cartDetail_selectAll).click()

    sleep(3)

    with allure.step("点击删除按钮"):
        goodssale.locator(*allPages.page_cartDetail_delBtn).click()

    sleep(3)

    with allure.step("点击确认按钮"):
        goodssale.locator(*allPages.page_cartDetail_confirmBtn).click()
    sleep(3)