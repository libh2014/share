# @Author   :muzhe
# @Time     :2022/6/2 20:44
# @File     :cart_page.py
# @Software :PyCharm
from time import sleep

import allure

from PYTEST.class06_practice.p08.VAR.TAOBAO_VAR import *
from PYTEST.class06_practice.p08.locate import allPages
from PYTEST.class06_practice.p08.logic.cartLogin_page import CatLoginPage
from PYTEST.class06_practice.p08.key_word.keyword import WebKeys

# 购车页面


class CartPage(WebKeys):
    # 商品结算
    @allure.step("商品结算")
    def pay(self):
        # 在报告里展示代码路径，方便查找
        with allure.step("流程代码路径：%s" % __file__):
            pass

        # # 复用登录流程
        # loginPage = CatLoginPage(self.driver)
        # loginPage.login(USERNAME, PASSWD)

        with allure.step("点击全选按钮"):
            self.locator(*allPages.page_cartDetail_selectAll).click()
            sleep(3)
        with allure.step("点击结算按钮"):
            self.locator(*allPages.page_cartDetail_payBtn).click()
            sleep(3)