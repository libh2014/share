# @Author   :muzhe
# @Time     :2022/6/2 22:07
# @File     :TAOBAO_VAR.py
# @Software :PyCharm

"""
变量统一管理文件，为了方便代码中识别，目录，文件，变量名全部大写
"""

# 购物车登录页面链接
CART_LOGIN_URL = "https://cart.taobao.com/cart.htm"
# 用户名
USERNAME = "kankankeji"
# 密码
PASSWD = "9957and77@"
# 淘宝首页
TAOBAO_URL = "http://www.taobao.com"