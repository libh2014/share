# @Author   :muzhe
# @Time     :2022/6/2 6:21
# @File     :main_run.py
# @Software :PyCharm
import os

import pytest


def run():
    pytest.main(['-v', '--alluredir', './report/result', '--clean-alluredir',
                # '--allure-no-capture' # 允许测试报告截取日志
                 ])
    os.system('allure generate ./report/result/ -o ./report/report_allure/ --clean')

if __name__ == '__main__':
    run()