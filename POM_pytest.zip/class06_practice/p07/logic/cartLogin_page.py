# @Author   :muzhe
# @Time     :2022/6/2 6:57
# @File     :cartLogin_page.py
# @Software :PyCharm
from time import sleep

import allure

from PYTEST.class06_practice.p07.VAR.TAOBAO_VAR import CART_LOGIN_URL
from PYTEST.class06_practice.p07.key_word.keyword import WebKeys


# 以页面为单位，封装常用的操作代码和元素
from PYTEST.class06_practice.p07.locate import allPages


class CatLoginPage(WebKeys):
    # 登录操作
    @allure.step("登录")
    def login(self,username,password,expect_title):
        """
        :param username:
        :param password:
        :param expect_title: 登录后断言，期望网页title包含字符串
        :return:
        """
        # 在报告里展示代码路径，方便查找
        with allure.step("流程代码路径：%s" % __file__):
            pass

        with allure.step("打开网页"):
            self.open(CART_LOGIN_URL)

        with allure.step("输入账户"):
            # 定位到账户名文本框
            self.locator(*allPages.page_indexLogin_user).send_keys(username)
        # self.open(CART_LOGIN_URL)
        # 定位到账户名文本框
        # self.locator(*allPages.page_indexLogin_user).send_keys(username)
        with allure.step("输入密码"):
        # 定位到密码框
            self.locator(*allPages.page_indexLogin_pwd).send_keys(password)
        with allure.step("点击登录"):
        # 点击登录按钮
            self.locator(*allPages.page_indexLogin_loginBtn).click()

        sleep(5)

        # 登录后的结果检查
        self.assert_title(expect_title)
