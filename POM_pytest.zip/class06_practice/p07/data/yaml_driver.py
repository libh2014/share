# @Author   :muzhe
# @Time     :2022/6/2 22:29
# @File     :yaml_driver.py
# @Software :PyCharm
import yaml


def load_yaml(path):
    file = open(path,'r',encoding='utf-8')
    data = yaml.load(file,Loader=yaml.FullLoader)
    return data